-- =========================================================
-- Ecogarzones - Esquema de referencia MySQL (MER documento)
-- Hibernate genera estas tablas con ddl-auto=update.
-- Este script sirve de documentacion / creacion manual.
-- =========================================================
CREATE DATABASE IF NOT EXISTS ecogarzones;
USE ecogarzones;

CREATE TABLE IF NOT EXISTS usuario (
    id_usuario      BIGINT AUTO_INCREMENT PRIMARY KEY,
    rut             VARCHAR(20) UNIQUE,
    nombre_completo VARCHAR(120),
    email           VARCHAR(120) UNIQUE NOT NULL,
    username        VARCHAR(60)  UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    rol             VARCHAR(20)  NOT NULL,
    avatar          VARCHAR(10)
);

CREATE TABLE IF NOT EXISTS plato (
    id_plato     BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre_plato VARCHAR(120),
    categoria    VARCHAR(30),
    porciones    INT,
    costo        INT,
    calorias     INT,
    tags         TEXT
);

CREATE TABLE IF NOT EXISTS personal (
    id_personal BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(120),
    rol         VARCHAR(30),
    disponible  BOOLEAN,
    rating      DOUBLE
);

CREATE TABLE IF NOT EXISTS evento (
    id_evento           BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha_evento        DATE,
    tipo_servicio       VARCHAR(80),
    cantidad_asistentes INT,
    preferencias        TEXT,
    estado_evento       VARCHAR(30),
    cliente_id          BIGINT,
    admin_id            BIGINT,
    garzones            INT,
    ayudantes           INT,
    coordinadores       INT,
    costo_base          BIGINT,
    costo_personal      BIGINT,
    costo_total         BIGINT,
    por_persona         BIGINT,
    creado_en           DATETIME,
    FOREIGN KEY (cliente_id) REFERENCES usuario(id_usuario),
    FOREIGN KEY (admin_id)   REFERENCES usuario(id_usuario)
);

CREATE TABLE IF NOT EXISTS asignacion_personal (
    id_asignacion    BIGINT AUTO_INCREMENT PRIMARY KEY,
    evento_id        BIGINT,
    personal_id      BIGINT,
    grupo_trabajo    VARCHAR(60),
    horas_trabajadas DOUBLE,
    estado_tarea     VARCHAR(30),
    FOREIGN KEY (evento_id)   REFERENCES evento(id_evento),
    FOREIGN KEY (personal_id) REFERENCES personal(id_personal)
);
