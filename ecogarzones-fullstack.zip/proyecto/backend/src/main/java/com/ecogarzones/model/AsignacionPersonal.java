package com.ecogarzones.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "asignacion_personal")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AsignacionPersonal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAsignacion;

    @ManyToOne
    @JoinColumn(name = "evento_id")
    private Evento evento;

    @ManyToOne
    @JoinColumn(name = "personal_id")
    private Personal personal;

    private String grupoTrabajo;
    private Double horasTrabajadas;
    private String estadoTarea;
}
