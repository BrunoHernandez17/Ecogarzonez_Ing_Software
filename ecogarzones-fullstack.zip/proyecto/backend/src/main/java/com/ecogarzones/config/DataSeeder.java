package com.ecogarzones.config;

import com.ecogarzones.model.*;
import com.ecogarzones.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seed(UsuarioRepository usuarios, PlatoRepository platos,
                           PersonalRepository personal, PasswordEncoder encoder) {
        return args -> {
            if (usuarios.count() == 0) {
                usuarios.save(Usuario.builder().username("admin").passwordHash(encoder.encode("admin123"))
                        .nombreCompleto("Carolina Vega").email("admin@ecogarzones.cl").rol(Rol.ADMINISTRADOR).avatar("CV").build());
                usuarios.save(Usuario.builder().username("cliente").passwordHash(encoder.encode("cliente123"))
                        .nombreCompleto("Rodrigo Munoz").email("cliente@ecogarzones.cl").rol(Rol.CLIENTE).avatar("RM").build());
                usuarios.save(Usuario.builder().username("chef").passwordHash(encoder.encode("chef123"))
                        .nombreCompleto("Marco Fuentes").email("chef@ecogarzones.cl").rol(Rol.CHEF).avatar("MF").build());
                usuarios.save(Usuario.builder().username("supervisor").passwordHash(encoder.encode("super123"))
                        .nombreCompleto("Ana Torres").email("super@ecogarzones.cl").rol(Rol.SUPERVISOR).avatar("AT").build());
                usuarios.save(Usuario.builder().username("empleado").passwordHash(encoder.encode("emp123"))
                        .nombreCompleto("Luis Perez").email("emp@ecogarzones.cl").rol(Rol.EMPLEADO).avatar("LP").build());
            }
            if (platos.count() == 0) {
                platos.save(Plato.builder().nombrePlato("Lomo Saltado Ejecutivo").categoria("principal").porciones(1).costo(4800).calorias(620).tags("sin-gluten").build());
                platos.save(Plato.builder().nombrePlato("Salmon al Limon con Quinoa").categoria("principal").porciones(1).costo(5600).calorias(480).tags("sin-lactosa").build());
                platos.save(Plato.builder().nombrePlato("Pasta Primavera Vegana").categoria("principal").porciones(1).costo(3200).calorias(390).tags("vegano,vegetariano").build());
                platos.save(Plato.builder().nombrePlato("Ensalada Cesar Premium").categoria("entrada").porciones(1).costo(1800).calorias(210).tags("").build());
                platos.save(Plato.builder().nombrePlato("Crema de Zapallo").categoria("entrada").porciones(1).costo(1400).calorias(180).tags("vegano").build());
                platos.save(Plato.builder().nombrePlato("Tiramisu Artesanal").categoria("postre").porciones(1).costo(2200).calorias(340).tags("vegetariano").build());
                platos.save(Plato.builder().nombrePlato("Fruta de Temporada").categoria("postre").porciones(1).costo(900).calorias(120).tags("vegano,sin-gluten").build());
            }
            if (personal.count() == 0) {
                personal.save(Personal.builder().nombre("Pedro Alvarado").rol("garzon").disponible(true).rating(4.8).build());
                personal.save(Personal.builder().nombre("Camila Soto").rol("garzon").disponible(true).rating(4.9).build());
                personal.save(Personal.builder().nombre("Javier Rojas").rol("garzon").disponible(false).rating(4.5).build());
                personal.save(Personal.builder().nombre("Valentina Cruz").rol("ayudante").disponible(true).rating(4.7).build());
                personal.save(Personal.builder().nombre("Diego Mora").rol("ayudante").disponible(true).rating(4.3).build());
                personal.save(Personal.builder().nombre("Sofia Nunez").rol("coordinador").disponible(true).rating(5.0).build());
            }
        };
    }
}
