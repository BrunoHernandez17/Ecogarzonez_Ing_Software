package com.ecogarzones.repository;

import com.ecogarzones.model.AsignacionPersonal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AsignacionPersonalRepository extends JpaRepository<AsignacionPersonal, Long> {
    List<AsignacionPersonal> findByEventoIdEvento(Long eventoId);
}
