package com.ecogarzones.service;

import com.ecogarzones.dto.CalculoResponse;
import com.ecogarzones.model.Plato;
import com.ecogarzones.repository.PlatoRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Motor Gastronomico y Calculo Automatico (ÉPICA 2).
 * Transforma numero de asistentes en metricas operativas.
 */
@Service
public class CalculoService {

    private static final int RATIO_GARZON = 15;
    private static final int RATIO_AYUDANTE = 30;
    private static final int SUELDO_GARZON = 35000;
    private static final int SUELDO_AYUDANTE = 25000;
    private static final int SUELDO_COORDINADOR = 50000;

    private final PlatoRepository platoRepo;

    public CalculoService(PlatoRepository platoRepo) {
        this.platoRepo = platoRepo;
    }

    public CalculoResponse calcular(int asistentes, List<String> preferencias) {
        if (asistentes <= 0) throw new IllegalArgumentException("Los asistentes deben ser mayor a 0");
        List<String> prefs = preferencias == null ? List.of() : preferencias;

        int garzones = (int) Math.ceil((double) asistentes / RATIO_GARZON);
        int ayudantes = (int) Math.ceil((double) asistentes / RATIO_AYUDANTE);
        int coordinadores = garzones > 3 ? 1 : 0;

        List<Plato> todos = platoRepo.findAll();
        List<Plato> filtrados = prefs.isEmpty() ? todos :
            todos.stream()
                .filter(p -> prefs.stream().anyMatch(pref -> tags(p).contains(pref)))
                .collect(Collectors.toList());

        List<Plato> entradas = porCategoria(filtrados, "entrada", 1);
        List<Plato> principales = porCategoria(filtrados, "principal", 2);
        List<Plato> postres = porCategoria(filtrados, "postre", 1);

        List<Plato> menu = new ArrayList<>();
        menu.addAll(entradas);
        menu.addAll(principales);
        menu.addAll(postres);

        long costoBase = (long) menu.stream().mapToInt(Plato::getCosto).sum() * asistentes;
        long costoPersonal = (long) garzones * SUELDO_GARZON
                + (long) ayudantes * SUELDO_AYUDANTE
                + (long) coordinadores * SUELDO_COORDINADOR;
        long costoTotal = costoBase + costoPersonal;

        return CalculoResponse.builder()
                .asistentes(asistentes)
                .garzones(garzones)
                .ayudantes(ayudantes)
                .coordinadores(coordinadores)
                .totalPersonal(garzones + ayudantes + coordinadores)
                .menuSugerido(menu)
                .costoBase(costoBase)
                .costoPersonal(costoPersonal)
                .costoTotal(costoTotal)
                .porPersona(asistentes > 0 ? Math.round((double) costoTotal / asistentes) : 0)
                .build();
    }

    private List<String> tags(Plato p) {
        if (p.getTags() == null || p.getTags().isBlank()) return List.of();
        return Arrays.asList(p.getTags().split(","));
    }

    private List<Plato> porCategoria(List<Plato> lista, String cat, int limite) {
        return lista.stream()
                .filter(p -> cat.equals(p.getCategoria()))
                .limit(limite)
                .collect(Collectors.toList());
    }
}
