package com.ecogarzones.controller;

import com.ecogarzones.model.Plato;
import com.ecogarzones.repository.PlatoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/platos")
@Tag(name = "Platos", description = "Gestion de recetas y menus (Chef)")
public class PlatoController {

    private final PlatoRepository repo;

    public PlatoController(PlatoRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    @Operation(summary = "Listar platos")
    public List<Plato> listar() { return repo.findAll(); }

    @PostMapping
    @PreAuthorize("hasAnyRole('CHEF','ADMINISTRADOR')")
    @Operation(summary = "Crear plato (Chef/Admin)")
    public Plato crear(@RequestBody Plato p) { return repo.save(p); }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('CHEF','ADMINISTRADOR')")
    @Operation(summary = "Actualizar plato")
    public Plato actualizar(@PathVariable Long id, @RequestBody Plato p) {
        p.setIdPlato(id);
        return repo.save(p);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('CHEF','ADMINISTRADOR')")
    @Operation(summary = "Eliminar plato")
    public void eliminar(@PathVariable Long id) { repo.deleteById(id); }
}
