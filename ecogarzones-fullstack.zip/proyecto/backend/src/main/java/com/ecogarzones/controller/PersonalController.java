package com.ecogarzones.controller;

import com.ecogarzones.model.Personal;
import com.ecogarzones.repository.PersonalRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/personal")
@Tag(name = "Personal", description = "Capital humano y disponibilidad")
public class PersonalController {

    private final PersonalRepository repo;

    public PersonalController(PersonalRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    @Operation(summary = "Listar personal")
    public List<Personal> listar() { return repo.findAll(); }

    @GetMapping("/disponibles")
    @Operation(summary = "Listar personal disponible")
    public List<Personal> disponibles() { return repo.findByDisponibleTrue(); }
}
