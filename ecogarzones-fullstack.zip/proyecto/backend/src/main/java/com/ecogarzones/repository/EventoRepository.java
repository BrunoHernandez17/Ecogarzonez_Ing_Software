package com.ecogarzones.repository;

import com.ecogarzones.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EventoRepository extends JpaRepository<Evento, Long> {
    List<Evento> findByClienteIdUsuario(Long clienteId);
    List<Evento> findByEstadoEvento(String estado);
}
