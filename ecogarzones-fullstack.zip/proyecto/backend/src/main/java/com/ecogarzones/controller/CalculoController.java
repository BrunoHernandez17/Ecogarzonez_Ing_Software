package com.ecogarzones.controller;

import com.ecogarzones.dto.CalculoResponse;
import com.ecogarzones.service.CalculoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/calculo")
@Tag(name = "Motor Gastronomico", description = "Calculo automatico de personal, menus y costos")
public class CalculoController {

    private final CalculoService service;

    public CalculoController(CalculoService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Simular calculo de evento sin persistir")
    public CalculoResponse calcular(@RequestParam int asistentes,
                                    @RequestBody(required = false) List<String> preferencias) {
        return service.calcular(asistentes, preferencias);
    }
}
