package com.ecogarzones.model;

public enum Rol {
    ADMINISTRADOR, CLIENTE, CHEF, SUPERVISOR, EMPLEADO
}
