package com.ecogarzones.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "personal")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Personal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPersonal;

    private String nombre;
    private String rol; // garzon, ayudante, coordinador
    private Boolean disponible;
    private Double rating;
}
