package com.ecogarzones.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "plato")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Plato {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPlato;

    private String nombrePlato;
    private String categoria; // entrada, principal, postre
    private Integer porciones;
    private Integer costo;
    private Integer calorias;

    @Column(columnDefinition = "TEXT")
    private String tags; // CSV: vegano,sin-gluten,...
}
