package com.ecogarzones.service;

import com.ecogarzones.dto.*;
import com.ecogarzones.model.Evento;
import com.ecogarzones.model.Usuario;
import com.ecogarzones.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EventoService {

    private final EventoRepository eventoRepo;
    private final UsuarioRepository usuarioRepo;
    private final CalculoService calculoService;

    public EventoService(EventoRepository eventoRepo, UsuarioRepository usuarioRepo, CalculoService calculoService) {
        this.eventoRepo = eventoRepo;
        this.usuarioRepo = usuarioRepo;
        this.calculoService = calculoService;
    }

    public List<Evento> listar() { return eventoRepo.findAll(); }

    public List<Evento> porCliente(Long clienteId) { return eventoRepo.findByClienteIdUsuario(clienteId); }

    public Evento crear(EventoRequest req) {
        CalculoResponse calc = calculoService.calcular(req.getCantidadAsistentes(), req.getPreferencias());
        Usuario cliente = req.getClienteId() != null ? usuarioRepo.findById(req.getClienteId()).orElse(null) : null;

        Evento e = Evento.builder()
                .fechaEvento(req.getFechaEvento())
                .tipoServicio(req.getTipoServicio())
                .cantidadAsistentes(req.getCantidadAsistentes())
                .preferencias(req.getPreferencias() == null ? "" : String.join(",", req.getPreferencias()))
                .estadoEvento("pendiente")
                .cliente(cliente)
                .garzones(calc.getGarzones())
                .ayudantes(calc.getAyudantes())
                .coordinadores(calc.getCoordinadores())
                .costoBase(calc.getCostoBase())
                .costoPersonal(calc.getCostoPersonal())
                .costoTotal(calc.getCostoTotal())
                .porPersona(calc.getPorPersona())
                .creadoEn(LocalDateTime.now())
                .build();
        return eventoRepo.save(e);
    }

    public Evento cambiarEstado(Long id, String estado) {
        Evento e = eventoRepo.findById(id).orElseThrow(() -> new RuntimeException("Evento no encontrado"));
        e.setEstadoEvento(estado);
        return eventoRepo.save(e);
    }

    public StatsResponse stats() {
        List<Evento> todos = eventoRepo.findAll();
        long total = todos.size();
        long pend = todos.stream().filter(e -> "pendiente".equals(e.getEstadoEvento())).count();
        long aprob = todos.stream().filter(e -> "aprobado".equals(e.getEstadoEvento())).count();
        long comp = todos.stream().filter(e -> "completado".equals(e.getEstadoEvento())).count();
        long ingreso = todos.stream()
                .filter(e -> !"rechazado".equals(e.getEstadoEvento()))
                .mapToLong(e -> e.getCostoTotal() == null ? 0 : e.getCostoTotal())
                .sum();
        return StatsResponse.builder().total(total).pendientes(pend)
                .aprobados(aprob).completados(comp).ingresoTotal(ingreso).build();
    }
}
