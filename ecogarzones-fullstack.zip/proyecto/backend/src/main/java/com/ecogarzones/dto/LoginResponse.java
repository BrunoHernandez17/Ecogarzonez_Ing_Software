package com.ecogarzones.dto;

import lombok.*;

@Data @AllArgsConstructor @NoArgsConstructor @Builder
public class LoginResponse {
    private String token;
    private Long id;
    private String username;
    private String name;
    private String role;
    private String avatar;
}
