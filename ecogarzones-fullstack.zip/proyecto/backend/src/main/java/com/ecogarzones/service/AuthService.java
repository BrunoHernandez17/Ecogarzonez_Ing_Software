package com.ecogarzones.service;

import com.ecogarzones.dto.*;
import com.ecogarzones.model.Usuario;
import com.ecogarzones.repository.UsuarioRepository;
import com.ecogarzones.security.JwtService;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AuthService {

    private final UsuarioRepository repo;
    private final JwtService jwtService;
    private final AuthenticationManager authManager;

    public AuthService(UsuarioRepository repo, JwtService jwtService, AuthenticationManager authManager) {
        this.repo = repo;
        this.jwtService = jwtService;
        this.authManager = authManager;
    }

    public LoginResponse login(LoginRequest req) {
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));

        Usuario u = repo.findByUsername(req.getUsername()).orElseThrow();
        String token = jwtService.generateToken(u.getUsername(),
                Map.of("role", u.getRol().name(), "id", u.getIdUsuario()));

        return LoginResponse.builder()
                .token(token)
                .id(u.getIdUsuario())
                .username(u.getUsername())
                .name(u.getNombreCompleto())
                .role(u.getRol().name().toLowerCase())
                .avatar(u.getAvatar())
                .build();
    }
}
