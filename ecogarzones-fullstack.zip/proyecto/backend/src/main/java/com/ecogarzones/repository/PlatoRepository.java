package com.ecogarzones.repository;

import com.ecogarzones.model.Plato;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlatoRepository extends JpaRepository<Plato, Long> {
    List<Plato> findByCategoria(String categoria);
}
