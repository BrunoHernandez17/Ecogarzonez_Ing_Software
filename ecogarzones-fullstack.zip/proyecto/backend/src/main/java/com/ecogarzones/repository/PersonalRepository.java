package com.ecogarzones.repository;

import com.ecogarzones.model.Personal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PersonalRepository extends JpaRepository<Personal, Long> {
    List<Personal> findByDisponibleTrue();
}
