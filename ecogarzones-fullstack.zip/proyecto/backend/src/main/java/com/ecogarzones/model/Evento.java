package com.ecogarzones.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "evento")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Evento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEvento;

    private LocalDate fechaEvento;
    private String tipoServicio;
    private Integer cantidadAsistentes;

    @Column(columnDefinition = "TEXT")
    private String preferencias;

    private String estadoEvento;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Usuario cliente;

    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Usuario admin;

    // Resultado del motor de calculo (persistido)
    private Integer garzones;
    private Integer ayudantes;
    private Integer coordinadores;
    private Long costoBase;
    private Long costoPersonal;
    private Long costoTotal;
    private Long porPersona;

    private LocalDateTime creadoEn;
}
