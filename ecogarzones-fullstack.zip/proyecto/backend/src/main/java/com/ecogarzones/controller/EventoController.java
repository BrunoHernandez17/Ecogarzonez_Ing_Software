package com.ecogarzones.controller;

import com.ecogarzones.dto.*;
import com.ecogarzones.model.Evento;
import com.ecogarzones.service.EventoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/eventos")
@Tag(name = "Eventos", description = "Ciclo de vida de eventos corporativos")
public class EventoController {

    private final EventoService service;

    public EventoController(EventoService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Listar todos los eventos")
    public List<Evento> listar() { return service.listar(); }

    @GetMapping("/cliente/{clienteId}")
    @Operation(summary = "Listar eventos de un cliente")
    public List<Evento> porCliente(@PathVariable Long clienteId) {
        return service.porCliente(clienteId);
    }

    @PostMapping
    @Operation(summary = "Crear evento", description = "Ejecuta el motor de calculo automatico")
    public ResponseEntity<Evento> crear(@Valid @RequestBody EventoRequest req) {
        return ResponseEntity.ok(service.crear(req));
    }

    @PutMapping("/{id}/estado")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    @Operation(summary = "Cambiar estado del evento (solo Admin)")
    public ResponseEntity<Evento> cambiarEstado(@PathVariable Long id, @RequestParam String estado) {
        return ResponseEntity.ok(service.cambiarEstado(id, estado));
    }

    @GetMapping("/stats")
    @Operation(summary = "Estadisticas consolidadas para dashboard")
    public StatsResponse stats() { return service.stats(); }
}
