package com.ecogarzones.dto;

import lombok.*;

@Data @AllArgsConstructor @NoArgsConstructor @Builder
public class StatsResponse {
    private long total;
    private long pendientes;
    private long aprobados;
    private long completados;
    private long ingresoTotal;
}
