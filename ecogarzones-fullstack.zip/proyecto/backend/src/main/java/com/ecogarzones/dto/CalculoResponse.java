package com.ecogarzones.dto;

import com.ecogarzones.model.Plato;
import lombok.*;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor @Builder
public class CalculoResponse {
    private Integer asistentes;
    private Integer garzones;
    private Integer ayudantes;
    private Integer coordinadores;
    private Integer totalPersonal;
    private List<Plato> menuSugerido;
    private Long costoBase;
    private Long costoPersonal;
    private Long costoTotal;
    private Long porPersona;
}
