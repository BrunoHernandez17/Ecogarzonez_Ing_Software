package com.ecogarzones.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class EventoRequest {
    @NotNull private LocalDate fechaEvento;
    @NotBlank private String tipoServicio;
    @Min(1) private Integer cantidadAsistentes;
    private List<String> preferencias;
    private Long clienteId;
}
