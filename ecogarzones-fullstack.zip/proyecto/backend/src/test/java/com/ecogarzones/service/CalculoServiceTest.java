package com.ecogarzones.service;

import com.ecogarzones.dto.CalculoResponse;
import com.ecogarzones.model.Plato;
import com.ecogarzones.repository.PlatoRepository;
import org.junit.jupiter.api.*;
import org.mockito.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CalculoServiceTest {

    @Mock PlatoRepository platoRepo;
    @InjectMocks CalculoService service;

    private List<Plato> platosMock() {
        return List.of(
            Plato.builder().idPlato(1L).nombrePlato("Lomo").categoria("principal").costo(4800).tags("sin-gluten").build(),
            Plato.builder().idPlato(2L).nombrePlato("Pasta Vegana").categoria("principal").costo(3200).tags("vegano,vegetariano").build(),
            Plato.builder().idPlato(3L).nombrePlato("Ensalada").categoria("entrada").costo(1800).tags("").build(),
            Plato.builder().idPlato(4L).nombrePlato("Crema").categoria("entrada").costo(1400).tags("vegano").build(),
            Plato.builder().idPlato(5L).nombrePlato("Tiramisu").categoria("postre").costo(2200).tags("vegetariano").build()
        );
    }

    @BeforeEach
    void setUp() { MockitoAnnotations.openMocks(this); }

    @Test
    @DisplayName("Calcula 2 garzones para 30 asistentes (ratio 1:15)")
    void calculaGarzonesCorrectos() {
        when(platoRepo.findAll()).thenReturn(platosMock());
        CalculoResponse r = service.calcular(30, null);
        assertEquals(2, r.getGarzones());
        assertEquals(1, r.getAyudantes()); // ceil(30/30)=1
        assertEquals(0, r.getCoordinadores()); // garzones <= 3
    }

    @Test
    @DisplayName("Asigna coordinador cuando garzones > 3")
    void asignaCoordinadorEnEventoGrande() {
        when(platoRepo.findAll()).thenReturn(platosMock());
        CalculoResponse r = service.calcular(100, null); // ceil(100/15)=7 garzones
        assertEquals(7, r.getGarzones());
        assertEquals(1, r.getCoordinadores());
    }

    @Test
    @DisplayName("Filtra solo platos veganos cuando se solicita")
    void filtraPreferenciaVegana() {
        when(platoRepo.findAll()).thenReturn(platosMock());
        CalculoResponse r = service.calcular(20, List.of("vegano"));
        assertTrue(r.getMenuSugerido().stream()
                .allMatch(p -> p.getTags().contains("vegano")));
    }

    @Test
    @DisplayName("Costo total = costo base + costo personal")
    void calculaCostoTotalCoherente() {
        when(platoRepo.findAll()).thenReturn(platosMock());
        CalculoResponse r = service.calcular(50, null);
        assertEquals(r.getCostoBase() + r.getCostoPersonal(), r.getCostoTotal());
        assertTrue(r.getPorPersona() > 0);
    }

    @Test
    @DisplayName("Lanza excepcion con asistentes invalidos")
    void rechazaAsistentesCero() {
        assertThrows(IllegalArgumentException.class, () -> service.calcular(0, null));
    }
}
