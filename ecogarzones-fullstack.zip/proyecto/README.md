# Ecogarzones — Plataforma de Gestión de Banquetería

Sistema integral de gestión de eventos corporativos. Stack completo según el Acta de Iniciación.

## Stack

- **Frontend:** React + Vite + JavaScript + Tailwind CSS. Conexión vía **Axios**.
- **API Gateway:** Spring Cloud Gateway (puerto 8080). Punto único de entrada.
- **Backend:** Spring Boot 3 + Java 21. Microservicio REST (puerto 8081).
- **Base de Datos:** MySQL 8.
- **Seguridad:** Spring Security + JWT.
- **Documentación / Pruebas:** Swagger (OpenAPI) + JUnit 5 + Mockito.

## Arquitectura

```
Frontend (5173)  →  API Gateway (8080)  →  Backend (8081)  →  MySQL (3306)
   Axios              Spring Cloud           Spring Boot         JPA
```

El frontend nunca habla directo con el backend. Todo pasa por el Gateway.

## Estructura

```
proyecto/
├── docker-compose.yml      # Levanta MySQL + Backend + Gateway
├── frontend/               # React + Vite + Axios
│   └── src/api/            # Cliente Axios + servicios
├── api-gateway/            # Spring Cloud Gateway
└── backend/                # Spring Boot + JPA + JWT + Swagger
    ├── src/main/java/com/ecogarzones/
    │   ├── config/         # Security, OpenAPI, DataSeeder
    │   ├── controller/     # REST endpoints
    │   ├── service/        # CalculoService (motor gastronómico)
    │   ├── model/          # Entidades JPA (MER)
    │   ├── repository/     # Spring Data JPA
    │   ├── security/       # JWT
    │   └── dto/
    └── src/test/           # Pruebas unitarias
```

## Cómo ejecutar

### Opción A — Docker (todo junto)

```bash
docker-compose up --build
```

Levanta MySQL, backend y gateway. Luego el frontend:

```bash
cd frontend
npm install
npm run dev
```

### Opción B — Manual

1. **MySQL.** Tener MySQL corriendo en `localhost:3306` (user `root`, pass `root`). La base `ecogarzones` se crea sola.

2. **Backend:**
```bash
cd backend
mvn spring-boot:run
```

3. **API Gateway:**
```bash
cd api-gateway
mvn spring-boot:run
```

4. **Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## Accesos

- App: http://localhost:5173
- API Gateway: http://localhost:8080
- Swagger UI: http://localhost:8081/swagger-ui.html
- API docs JSON: http://localhost:8081/v3/api-docs

## Usuarios de prueba

El `DataSeeder` los crea automáticamente al iniciar:

| Usuario | Contraseña | Rol |
|---|---|---|
| admin | admin123 | Administrador |
| cliente | cliente123 | Cliente |
| chef | chef123 | Chef |
| supervisor | super123 | Supervisor |
| empleado | emp123 | Empleado |

> El frontend tiene **fallback offline**: si el backend está apagado, permite login con estos mismos usuarios usando datos locales.

## Pruebas unitarias (PU)

```bash
cd backend
mvn test
```

Cobertura incluida:
- `CalculoServiceTest`: motor gastronómico (ratios de personal, filtro dietético, costos, validaciones).
- `AuthControllerTest`: login con credenciales válidas e inválidas.

## Endpoints principales

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/auth/login` | Login, retorna JWT |
| GET | `/api/eventos` | Listar eventos |
| POST | `/api/eventos` | Crear evento (ejecuta motor de cálculo) |
| PUT | `/api/eventos/{id}/estado` | Cambiar estado (solo Admin) |
| GET | `/api/eventos/stats` | KPIs del dashboard |
| POST | `/api/calculo` | Simular cálculo sin guardar |
| GET | `/api/platos` | Listar platos |
| GET | `/api/personal/disponibles` | Personal disponible |

## Notas

- La clave JWT y credenciales MySQL se configuran por variables de entorno (`JWT_SECRET`, `DB_USER`, `DB_PASSWORD`). Cambiarlas en producción.
- Hibernate genera el esquema con `ddl-auto=update`. El DDL de referencia está en `backend/src/main/resources/db/schema.sql`.
