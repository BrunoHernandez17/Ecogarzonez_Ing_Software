import { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { DataProvider } from "./context/DataContext";
import Login from "./pages/Login";
import Layout from "./components/Layout";
import AdminDashboard from "./pages/AdminDashboard";
import AdminReports from "./pages/AdminReports";
import ClientPortal from "./pages/ClientPortal";
import ChefStation from "./pages/ChefStation";
import SupervisorPanel from "./pages/SupervisorPanel";
import EmployeeView from "./pages/EmployeeView";

const DEFAULT_VIEW = {
  administrador: "dashboard",
  cliente: "mi-portal",
  chef: "recetas",
  supervisor: "asignacion",
  empleado: "mis-turnos",
};

function AppContent() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState(
    user ? DEFAULT_VIEW[user.role] : "dashboard"
  );

  if (!user) return <Login />;

  const renderView = () => {
    switch (user.role) {
      case "administrador":
        if (currentView === "reportes") return <AdminReports />;
        if (currentView === "eventos") return <SupervisorPanel view="eventos-supervisor" />;
        if (currentView === "personal") return <SupervisorPanel view="personal" />;
        return <AdminDashboard />;

      case "cliente":
        return <ClientPortal view={currentView} />;

      case "chef":
        return <ChefStation view={currentView} />;

      case "supervisor":
        return <SupervisorPanel view={currentView} />;

      case "empleado":
        return <EmployeeView view={currentView} />;

      default:
        return <div className="text-white p-8">Vista no encontrada</div>;
    }
  };

  return (
    <Layout currentView={currentView} setCurrentView={setCurrentView}>
      {renderView()}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}
