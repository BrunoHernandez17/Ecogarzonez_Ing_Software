import { createContext, useContext, useState, useEffect } from "react";

const INITIAL_DISHES = [
  { id: 1, name: "Lomo Saltado Ejecutivo", category: "principal", porciones: 1, costo: 4800, calorias: 620, tags: ["sin-gluten"] },
  { id: 2, name: "Salmón al Limón con Quinoa", category: "principal", porciones: 1, costo: 5600, calorias: 480, tags: ["sin-lactosa"] },
  { id: 3, name: "Pasta Primavera Vegana", category: "principal", porciones: 1, costo: 3200, calorias: 390, tags: ["vegano", "vegetariano"] },
  { id: 4, name: "Ensalada César Premium", category: "entrada", porciones: 1, costo: 1800, calorias: 210, tags: [] },
  { id: 5, name: "Crema de Zapallo", category: "entrada", porciones: 1, costo: 1400, calorias: 180, tags: ["vegano"] },
  { id: 6, name: "Tiramisú Artesanal", category: "postre", porciones: 1, costo: 2200, calorias: 340, tags: ["vegetariano"] },
  { id: 7, name: "Fruta de Temporada", category: "postre", porciones: 1, costo: 900, calorias: 120, tags: ["vegano", "sin-gluten"] },
];

const INITIAL_STAFF = [
  { id: 1, name: "Pedro Alvarado", role: "garzon", disponible: true, rating: 4.8 },
  { id: 2, name: "Camila Soto", role: "garzon", disponible: true, rating: 4.9 },
  { id: 3, name: "Javier Rojas", role: "garzon", disponible: false, rating: 4.5 },
  { id: 4, name: "Valentina Cruz", role: "ayudante", disponible: true, rating: 4.7 },
  { id: 5, name: "Diego Mora", role: "ayudante", disponible: true, rating: 4.3 },
  { id: 6, name: "Sofía Núñez", role: "coordinador", disponible: true, rating: 5.0 },
];

function loadFromStorage(key, fallback) {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

const DataContext = createContext(null);

export function DataProvider({ children }) {
  const [events, setEvents] = useState(() => loadFromStorage("eco_events", []));
  const [dishes, setDishes] = useState(() => loadFromStorage("eco_dishes", INITIAL_DISHES));
  const [staff, setStaff] = useState(() => loadFromStorage("eco_staff", INITIAL_STAFF));
  const [assignments, setAssignments] = useState(() => loadFromStorage("eco_assignments", {}));

  useEffect(() => saveToStorage("eco_events", events), [events]);
  useEffect(() => saveToStorage("eco_dishes", dishes), [dishes]);
  useEffect(() => saveToStorage("eco_staff", staff), [staff]);
  useEffect(() => saveToStorage("eco_assignments", assignments), [assignments]);

  // Motor de cálculo gastronómico
  const calcularEvento = (asistentes, preferencias = []) => {
    const ratio_garzon = 15; // 1 garzón por cada 15 personas
    const ratio_ayudante = 30;
    const garzones = Math.ceil(asistentes / ratio_garzon);
    const ayudantes = Math.ceil(asistentes / ratio_ayudante);
    const coordinadores = garzones > 3 ? 1 : 0;

    const filtroDietetico = preferencias.length > 0
      ? dishes.filter(d => preferencias.some(p => d.tags.includes(p)))
      : dishes;

    const entradas = filtroDietetico.filter(d => d.category === "entrada");
    const principales = filtroDietetico.filter(d => d.category === "principal");
    const postres = filtroDietetico.filter(d => d.category === "postre");

    const menuSugerido = [
      ...(entradas.slice(0, 1)),
      ...(principales.slice(0, 2)),
      ...(postres.slice(0, 1)),
    ];

    const costoBase = menuSugerido.reduce((sum, d) => sum + d.costo, 0) * asistentes;
    const costoPersonal = (garzones * 35000) + (ayudantes * 25000) + (coordinadores * 50000);
    const costoTotal = costoBase + costoPersonal;

    return {
      asistentes,
      garzones,
      ayudantes,
      coordinadores,
      totalPersonal: garzones + ayudantes + coordinadores,
      menuSugerido,
      costoBase,
      costoPersonal,
      costoTotal,
      porPersona: Math.round(costoTotal / asistentes),
    };
  };

  const addEvent = (eventData) => {
    const calc = calcularEvento(eventData.asistentes, eventData.preferencias);
    const newEvent = {
      id: Date.now(),
      ...eventData,
      calculo: calc,
      estado: "pendiente",
      creadoEn: new Date().toISOString(),
    };
    setEvents(prev => [newEvent, ...prev]);
    return newEvent;
  };

  const updateEventStatus = (id, estado) => {
    setEvents(prev => prev.map(e => e.id === id ? { ...e, estado } : e));
  };

  const assignStaff = (eventId, staffIds) => {
    setAssignments(prev => ({ ...prev, [eventId]: staffIds }));
  };

  const addDish = (dish) => {
    const newDish = { id: Date.now(), ...dish };
    setDishes(prev => [...prev, newDish]);
  };

  const updateDish = (id, data) => {
    setDishes(prev => prev.map(d => d.id === id ? { ...d, ...data } : d));
  };

  const deleteDish = (id) => {
    setDishes(prev => prev.filter(d => d.id !== id));
  };

  const getStats = () => {
    const total = events.length;
    const pendientes = events.filter(e => e.estado === "pendiente").length;
    const aprobados = events.filter(e => e.estado === "aprobado").length;
    const completados = events.filter(e => e.estado === "completado").length;
    const ingresoTotal = events
      .filter(e => e.estado !== "rechazado")
      .reduce((sum, e) => sum + (e.calculo?.costoTotal || 0), 0);
    return { total, pendientes, aprobados, completados, ingresoTotal };
  };

  return (
    <DataContext.Provider value={{
      events, dishes, staff, assignments,
      addEvent, updateEventStatus, assignStaff,
      addDish, updateDish, deleteDish,
      calcularEvento, getStats,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export const useData = () => useContext(DataContext);
