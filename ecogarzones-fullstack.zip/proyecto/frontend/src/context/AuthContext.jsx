import { createContext, useContext, useState } from "react";
import { authApi } from "../api/authApi";

// Fallback demo: si el backend no responde, permite login offline
const DEMO_USERS = [
  { id: 1, username: "admin", password: "admin123", role: "administrador", name: "Carolina Vega", avatar: "CV" },
  { id: 2, username: "cliente", password: "cliente123", role: "cliente", name: "Rodrigo Muñoz", avatar: "RM" },
  { id: 3, username: "chef", password: "chef123", role: "chef", name: "Marco Fuentes", avatar: "MF" },
  { id: 4, username: "supervisor", password: "super123", role: "supervisor", name: "Ana Torres", avatar: "AT" },
  { id: 5, username: "empleado", password: "emp123", role: "empleado", name: "Luis Pérez", avatar: "LP" },
];

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("eco_session");
    return saved ? JSON.parse(saved) : null;
  });
  const [error, setError] = useState("");

  const login = async (username, password) => {
    setError("");
    try {
      // Intenta login contra el backend (via API Gateway)
      const data = await authApi.login(username, password);
      const session = {
        id: data.id, username: data.username, role: data.role,
        name: data.name, avatar: data.avatar, token: data.token,
      };
      setUser(session);
      localStorage.setItem("eco_session", JSON.stringify(session));
      return true;
    } catch (err) {
      // Fallback offline si el backend no esta disponible
      const noBackend = !err.response;
      if (noBackend) {
        const found = DEMO_USERS.find(u => u.username === username && u.password === password);
        if (found) {
          const { password: _, ...safe } = found;
          const session = { ...safe, token: null, offline: true };
          setUser(session);
          localStorage.setItem("eco_session", JSON.stringify(session));
          return true;
        }
      }
      setError("Credenciales incorrectas. Intenta nuevamente.");
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("eco_session");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, error, setError }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
