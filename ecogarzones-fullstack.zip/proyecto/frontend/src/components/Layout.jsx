import { useState } from "react";
import { useAuth } from "../context/AuthContext";

const NAV_BY_ROLE = {
  administrador: [
    { key: "dashboard", label: "Dashboard", icon: "📊" },
    { key: "eventos", label: "Gestión de Eventos", icon: "📋" },
    { key: "reportes", label: "Reportes de Costos", icon: "💰" },
    { key: "personal", label: "Personal", icon: "👥" },
  ],
  cliente: [
    { key: "mi-portal", label: "Mi Portal", icon: "🏠" },
    { key: "nuevo-evento", label: "Solicitar Evento", icon: "➕" },
    { key: "mis-eventos", label: "Mis Eventos", icon: "📅" },
  ],
  chef: [
    { key: "recetas", label: "Recetas y Menús", icon: "🍽️" },
    { key: "eventos-chef", label: "Eventos Asignados", icon: "📋" },
  ],
  supervisor: [
    { key: "asignacion", label: "Asignación de Personal", icon: "🗂️" },
    { key: "eventos-supervisor", label: "Eventos", icon: "📅" },
    { key: "personal", label: "Personal", icon: "👥" },
  ],
  empleado: [
    { key: "mis-turnos", label: "Mis Turnos", icon: "🕐" },
    { key: "mis-eventos", label: "Mis Eventos", icon: "📅" },
  ],
};

const ROLE_COLORS = {
  administrador: "from-amber-300 via-amber-500 to-orange-700",
  cliente: "from-stone-200 via-amber-300 to-amber-600",
  chef: "from-orange-200 via-orange-400 to-red-700",
  supervisor: "from-zinc-200 via-stone-300 to-stone-600",
  empleado: "from-stone-300 via-stone-400 to-stone-700",
};

const ROLE_LABELS = {
  administrador: "Administrador",
  cliente: "Cliente",
  chef: "Chef Ejecutivo",
  supervisor: "Supervisor",
  empleado: "Empleado",
};

export default function Layout({ currentView, setCurrentView, children }) {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navItems = NAV_BY_ROLE[user?.role] || [];
  const roleColor = ROLE_COLORS[user?.role] || "from-emerald-500 to-teal-600";
  const currentLabel = navItems.find((n) => n.key === currentView)?.label || "Panel";

  return (
    <div className="min-h-screen flex bg-transparent">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/70 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed top-0 left-0 h-full w-[290px] z-30 flex flex-col border-r border-stone-800/80 bg-[#100d0a]/95 backdrop-blur-xl
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:relative lg:flex
      `}>
        {/* Brand */}
        <div className="p-7 border-b border-stone-800/80">
          <div className="flex items-center gap-4">
            <div className={`w-11 h-11 bg-gradient-to-br ${roleColor} rounded-2xl flex items-center justify-center shadow-lg shadow-amber-950/40 flex-shrink-0`}>
              <span className="text-lg text-stone-950">E</span>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-[0.35em] text-stone-500 mb-1">Event Platform</p>
              <h1 className="text-white font-bold text-lg tracking-tight editorial-title">
                Ecogarzones
              </h1>
              <p className="text-stone-400 text-xs">Operaciones y produccion corporativa</p>
            </div>
          </div>
        </div>

        {/* User card */}
        <div className="p-5 border-b border-stone-800/80">
          <div className="venue-card px-4 py-4 flex items-center gap-3">
            <div className={`w-11 h-11 bg-gradient-to-br ${roleColor} rounded-xl flex items-center justify-center text-stone-950 font-bold text-sm flex-shrink-0`}>
              {user?.avatar}
            </div>
            <div className="min-w-0">
              <p className="text-white text-sm font-medium truncate">{user?.name}</p>
              <p className="text-[11px] uppercase tracking-[0.2em] text-stone-500 mt-0.5">Sesion activa</p>
              <p className={`text-xs font-medium bg-gradient-to-r ${roleColor} bg-clip-text text-transparent mt-1`}>
                {ROLE_LABELS[user?.role]}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="px-5 pt-5">
          <p className="text-[10px] uppercase tracking-[0.35em] text-stone-500">Navegacion</p>
        </div>
        <nav className="flex-1 p-5 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => {
                setCurrentView(item.key);
                setSidebarOpen(false);
              }}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium transition-all duration-200 border
                ${currentView === item.key
                  ? `bg-gradient-to-r ${roleColor} text-stone-950 border-transparent shadow-lg shadow-amber-950/20`
                  : "text-stone-300 border-stone-800 bg-stone-900/40 hover:text-white hover:border-stone-700 hover:bg-stone-900/80"
                }
              `}
            >
              <span className={`text-base ${currentView === item.key ? "text-stone-950" : "text-amber-300"}`}>{item.icon}</span>
              <span className="flex-1 text-left">{item.label}</span>
              {currentView === item.key && <span className="text-xs font-semibold uppercase tracking-[0.2em]">Live</span>}
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-5 border-t border-stone-800/80">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium text-stone-400 border border-stone-800 bg-stone-900/40 hover:text-white hover:border-stone-700 hover:bg-stone-900/80 transition-all duration-150"
          >
            <span>🚪</span>
            Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 lg:ml-0">
        {/* Topbar */}
        <header className="sticky top-0 z-10 border-b border-stone-800/80 bg-[#120f0c]/78 backdrop-blur-xl">
          <div className="px-4 py-4 sm:px-6 flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-stone-400 hover:text-white p-2 rounded-xl hover:bg-stone-800/80 transition-colors border border-stone-800"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="flex-1">
            <p className="text-[10px] uppercase tracking-[0.35em] text-stone-500 mb-1">Centro de control</p>
            <h2 className="text-white font-semibold text-lg editorial-title">{currentLabel}</h2>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden sm:flex items-center gap-2 rounded-full border border-stone-700/80 bg-stone-900/60 px-4 py-2">
              <span className="text-amber-300 text-xs">●</span>
              <span className="text-stone-200 text-xs uppercase tracking-[0.2em]">Sistema activo</span>
            </div>
            <div className={`hidden md:flex h-10 min-w-10 rounded-full bg-gradient-to-br ${roleColor} items-center justify-center text-stone-950 font-semibold px-3`}>
              {user?.avatar}
            </div>
          </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <div className="min-h-full px-4 py-6 sm:px-6 lg:px-8">
            <div className="absolute pointer-events-none inset-x-0 top-0 h-64 bg-gradient-to-b from-amber-500/5 to-transparent" />
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
