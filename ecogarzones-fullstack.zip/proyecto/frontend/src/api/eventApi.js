import api from "./client";

export const eventApi = {
  listar: () => api.get("/api/eventos").then((r) => r.data),
  porCliente: (clienteId) => api.get(`/api/eventos/cliente/${clienteId}`).then((r) => r.data),
  crear: (evento) => api.post("/api/eventos", evento).then((r) => r.data),
  cambiarEstado: (id, estado) =>
    api.put(`/api/eventos/${id}/estado`, null, { params: { estado } }).then((r) => r.data),
  stats: () => api.get("/api/eventos/stats").then((r) => r.data),
  calcular: (asistentes, preferencias = []) =>
    api.post("/api/calculo", preferencias, { params: { asistentes } }).then((r) => r.data),
};
