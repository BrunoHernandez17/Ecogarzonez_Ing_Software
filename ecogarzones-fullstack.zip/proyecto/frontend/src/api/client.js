import axios from "axios";

// API Gateway en puerto 8080 (no el backend directo 8081)
const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8080";

const api = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
});

// Inyecta el token JWT en cada request
api.interceptors.request.use((config) => {
  const session = localStorage.getItem("eco_session");
  if (session) {
    const { token } = JSON.parse(session);
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Maneja expiracion de sesion
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      // token vencido -> limpia sesion
      const path = err.config?.url || "";
      if (!path.includes("/auth/login")) {
        localStorage.removeItem("eco_session");
        window.location.reload();
      }
    }
    return Promise.reject(err);
  }
);

export default api;
