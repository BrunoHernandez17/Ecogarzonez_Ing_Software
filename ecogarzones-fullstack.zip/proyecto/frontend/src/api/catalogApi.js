import api from "./client";

export const catalogApi = {
  platos: () => api.get("/api/platos").then((r) => r.data),
  crearPlato: (plato) => api.post("/api/platos", plato).then((r) => r.data),
  actualizarPlato: (id, plato) => api.put(`/api/platos/${id}`, plato).then((r) => r.data),
  eliminarPlato: (id) => api.delete(`/api/platos/${id}`).then((r) => r.data),
  personal: () => api.get("/api/personal").then((r) => r.data),
  personalDisponible: () => api.get("/api/personal/disponibles").then((r) => r.data),
};
