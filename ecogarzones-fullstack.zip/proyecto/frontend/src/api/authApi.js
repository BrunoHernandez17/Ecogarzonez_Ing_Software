import api from "./client";

export const authApi = {
  login: (username, password) =>
    api.post("/api/auth/login", { username, password }).then((r) => r.data),
};
