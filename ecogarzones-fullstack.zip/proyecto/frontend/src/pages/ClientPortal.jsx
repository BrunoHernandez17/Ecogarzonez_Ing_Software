import { useState } from "react";
import { useData } from "../context/DataContext";
import { useAuth } from "../context/AuthContext";

const STEPS = ["Información", "Asistentes", "Menú", "Confirmación"];
const DIETAS = [
  { key: "vegano", label: "Vegano", icon: "🌱" },
  { key: "vegetariano", label: "Vegetariano", icon: "🥗" },
  { key: "sin-gluten", label: "Sin Gluten", icon: "🌾" },
  { key: "sin-lactosa", label: "Sin Lactosa", icon: "🥛" },
];

function StepIndicator({ current, steps }) {
  return (
    <div className="flex items-center gap-0 mb-8">
      {steps.map((s, i) => (
        <div key={s} className="flex items-center flex-1">
          <div className="flex flex-col items-center">
            <div className={`
              w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all
              ${i < current ? "bg-amber-400 text-stone-950" : i === current ? "bg-gradient-to-br from-amber-200 to-orange-500 text-stone-950 shadow-lg shadow-amber-950/40" : "bg-stone-800 text-stone-600"}
            `}>
              {i < current ? "✓" : i + 1}
            </div>
            <span className={`text-xs mt-1 font-medium hidden sm:block ${i === current ? "text-amber-300" : "text-stone-600"}`}>{s}</span>
          </div>
          {i < steps.length - 1 && (
            <div className={`flex-1 h-px mx-2 mb-5 sm:mb-0 transition-all ${i < current ? "bg-amber-400" : "bg-stone-800"}`} />
          )}
        </div>
      ))}
    </div>
  );
}

function EventCard({ event }) {
  const fmt = (n) => `$${n.toLocaleString("es-CL")}`;
  const statusMap = {
    pendiente: { label: "Pendiente", cls: "text-yellow-400 bg-yellow-950/50 border-yellow-800/50" },
    aprobado: { label: "Aprobado", cls: "text-amber-300 bg-amber-950/40 border-amber-800/50" },
    rechazado: { label: "Rechazado", cls: "text-red-400 bg-red-950/50 border-red-800/50" },
  };
  const s = statusMap[event.estado] || statusMap.pendiente;

  return (
    <div className="venue-card p-5 hover:border-stone-700 transition-colors">
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="text-white font-semibold">{event.nombre}</h3>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-lg border flex-shrink-0 ${s.cls}`}>{s.label}</span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-sm text-stone-400">
        <span>📅 {new Date(event.fecha).toLocaleDateString("es-CL")}</span>
        <span>👥 {event.asistentes} personas</span>
        <span>🍽️ {event.lugar}</span>
        <span className="text-amber-300 font-medium">{fmt(event.calculo?.costoTotal || 0)}</span>
      </div>
    </div>
  );
}

export default function ClientPortal({ view }) {
  const { user } = useAuth();
  const { addEvent, events, calcularEvento } = useData();
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [preview, setPreview] = useState(null);

  const [form, setForm] = useState({
    nombre: "", fecha: "", lugar: "", observaciones: "",
    asistentes: 50, preferencias: [],
  });

  const myEvents = events.filter(e => e.clienteId === user?.id);

  const handlePref = (key) => {
    setForm(p => ({
      ...p,
      preferencias: p.preferencias.includes(key)
        ? p.preferencias.filter(x => x !== key)
        : [...p.preferencias, key]
    }));
  };

  const nextStep = () => {
    if (step === 1) {
      setPreview(calcularEvento(form.asistentes, form.preferencias));
    }
    setStep(s => Math.min(s + 1, 3));
  };

  const handleSubmit = () => {
    addEvent({ ...form, clienteId: user?.id });
    setSubmitted(true);
  };

  const reset = () => {
    setStep(0);
    setSubmitted(false);
    setPreview(null);
    setForm({ nombre: "", fecha: "", lugar: "", observaciones: "", asistentes: 50, preferencias: [] });
  };

  const fmt = (n) => `$${n.toLocaleString("es-CL")}`;

  if (view === "mis-eventos") {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <div>
          <p className="text-[11px] uppercase tracking-[0.35em] text-stone-500 mb-2">Historial</p>
          <h1 className="text-white text-3xl editorial-title">Mis Eventos</h1>
        </div>
        {myEvents.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-5xl mb-4">📭</div>
            <p className="text-stone-400">Aún no tienes eventos solicitados.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {myEvents.map(e => <EventCard key={e.id} event={e} />)}
          </div>
        )}
      </div>
    );
  }

  if (view === "mi-portal") {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <div className="venue-panel p-7">
          <p className="text-[11px] uppercase tracking-[0.35em] text-stone-500 mb-3">Portal cliente</p>
          <h1 className="text-white text-3xl sm:text-4xl editorial-title">
            Bienvenido, {user?.name.split(" ")[0]} 👋
          </h1>
          <p className="text-stone-300 text-sm mt-3 max-w-xl">Gestiona solicitudes, revisa el estado de tus eventos y obtén una estimación clara de operación y servicio.</p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-stone-900/70 border border-stone-700/70 rounded-[24px] p-5">
            <p className="text-stone-400 text-sm uppercase tracking-[0.2em]">Mis Eventos</p>
            <p className="text-white text-3xl mt-2 editorial-title">{myEvents.length}</p>
          </div>
          <div className="bg-amber-950/30 border border-amber-800/30 rounded-[24px] p-5">
            <p className="text-stone-400 text-sm uppercase tracking-[0.2em]">Aprobados</p>
            <p className="text-white text-3xl mt-2 editorial-title">{myEvents.filter(e => e.estado === "aprobado").length}</p>
          </div>
        </div>
        {myEvents.slice(0, 3).map(e => <EventCard key={e.id} event={e} />)}
      </div>
    );
  }

  // Wizard nuevo evento
  return (
    <div className="max-w-2xl mx-auto">
      <p className="text-[11px] uppercase tracking-[0.35em] text-stone-500 mb-2">Cotizacion</p>
      <h1 className="text-white text-3xl editorial-title mb-2">
        Solicitar Nuevo Evento
      </h1>
      <p className="text-stone-400 text-sm mb-8">Completa el formulario para cotizar tu evento corporativo manteniendo el flujo actual del sistema.</p>

      {!submitted ? (
        <>
          <StepIndicator current={step} steps={STEPS} />

          <div className="venue-panel p-6">
            {/* Step 0 */}
            {step === 0 && (
              <div className="space-y-4">
                <h2 className="text-white font-semibold text-lg mb-5">Información del Evento</h2>
                {[
                  { key: "nombre", label: "Nombre del Evento", placeholder: "Ej: Reunión Anual Gerencia 2025" },
                  { key: "lugar", label: "Lugar / Venue", placeholder: "Ej: Salón Espacio Cívico, Providencia" },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-stone-400 text-sm font-medium block mb-2">{f.label}</label>
                    <input
                      type="text"
                      value={form[f.key]}
                      onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      className="w-full bg-stone-950/60 border border-stone-700 rounded-2xl px-4 py-3 text-white placeholder-stone-600 focus:outline-none focus:border-amber-400 transition-all text-sm"
                    />
                  </div>
                ))}
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-2">Fecha del Evento</label>
                  <input
                    type="date"
                    value={form.fecha}
                    min={new Date().toISOString().split("T")[0]}
                    onChange={e => setForm(p => ({ ...p, fecha: e.target.value }))}
                    className="w-full bg-stone-950/60 border border-stone-700 rounded-2xl px-4 py-3 text-white focus:outline-none focus:border-amber-400 transition-all text-sm"
                  />
                </div>
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-2">Observaciones</label>
                  <textarea
                    value={form.observaciones}
                    onChange={e => setForm(p => ({ ...p, observaciones: e.target.value }))}
                    rows={3}
                    placeholder="Indicaciones especiales, horarios, etc."
                    className="w-full bg-stone-950/60 border border-stone-700 rounded-2xl px-4 py-3 text-white placeholder-stone-600 focus:outline-none focus:border-amber-400 transition-all text-sm resize-none"
                  />
                </div>
              </div>
            )}

            {/* Step 1 */}
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-white font-semibold text-lg">Asistentes y Preferencias</h2>
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-3">
                    Número de Asistentes: <span className="text-white font-bold text-xl">{form.asistentes}</span>
                  </label>
                  <input
                    type="range" min={10} max={500} step={5}
                    value={form.asistentes}
                    onChange={e => setForm(p => ({ ...p, asistentes: +e.target.value }))}
                    className="w-full accent-amber-400"
                  />
                  <div className="flex justify-between text-stone-600 text-xs mt-1">
                    <span>10</span><span>500</span>
                  </div>
                </div>
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-3">Preferencias Dietéticas</label>
                  <div className="grid grid-cols-2 gap-3">
                    {DIETAS.map(d => (
                      <button
                        key={d.key}
                        onClick={() => handlePref(d.key)}
                        className={`flex items-center gap-2 px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                          form.preferencias.includes(d.key)
                            ? "bg-amber-950/40 border-amber-700 text-amber-200"
                            : "bg-stone-800/60 border-stone-700 text-stone-400 hover:border-stone-600"
                        }`}
                      >
                        <span>{d.icon}</span>{d.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 2 - Preview */}
            {step === 2 && preview && (
              <div className="space-y-5">
                <h2 className="text-white font-semibold text-lg">Resumen del Cálculo</h2>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Garzones", val: preview.garzones, icon: "🤵" },
                    { label: "Ayudantes", val: preview.ayudantes, icon: "👤" },
                    { label: "Coordinador", val: preview.coordinadores, icon: "📋" },
                  ].map(s => (
                    <div key={s.label} className="bg-stone-950/45 border border-stone-800 rounded-2xl p-3 text-center">
                      <div className="text-2xl mb-1">{s.icon}</div>
                      <div className="text-white font-bold text-xl">{s.val}</div>
                      <div className="text-stone-500 text-xs">{s.label}</div>
                    </div>
                  ))}
                </div>
                <div className="bg-stone-950/45 border border-stone-800 rounded-2xl p-4 space-y-2">
                  <h3 className="text-white font-medium text-sm mb-3">Menú Sugerido</h3>
                  {preview.menuSugerido.map(d => (
                    <div key={d.id} className="flex justify-between text-sm">
                      <span className="text-stone-300">{d.name}</span>
                      <span className="text-amber-300">{fmt(d.costo * preview.asistentes)}</span>
                    </div>
                  ))}
                </div>
                <div className="bg-amber-950/30 border border-amber-800/30 rounded-2xl p-4 space-y-2 text-sm">
                  <div className="flex justify-between text-stone-400">
                    <span>Costo alimentación</span><span>{fmt(preview.costoBase)}</span>
                  </div>
                  <div className="flex justify-between text-stone-400">
                    <span>Costo personal</span><span>{fmt(preview.costoPersonal)}</span>
                  </div>
                  <div className="flex justify-between text-white font-bold border-t border-emerald-800/40 pt-2">
                    <span>Total Estimado</span><span className="text-amber-300 text-lg">{fmt(preview.costoTotal)}</span>
                  </div>
                  <p className="text-stone-500 text-xs text-right">{fmt(preview.porPersona)} por persona</p>
                </div>
              </div>
            )}

            {/* Step 3 - Confirm */}
            {step === 3 && (
              <div className="space-y-4">
                <h2 className="text-white font-semibold text-lg">Confirmar Solicitud</h2>
                <div className="bg-stone-950/45 border border-stone-800 rounded-2xl p-4 space-y-2 text-sm">
                  {[
                    ["Evento", form.nombre],
                    ["Fecha", form.fecha ? new Date(form.fecha).toLocaleDateString("es-CL") : "—"],
                    ["Lugar", form.lugar],
                    ["Asistentes", form.asistentes],
                    ["Preferencias", form.preferencias.join(", ") || "Ninguna"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between">
                      <span className="text-stone-500">{k}</span>
                      <span className="text-white text-right">{v}</span>
                    </div>
                  ))}
                </div>
                <div className="bg-amber-950/30 border border-amber-700/30 rounded-2xl p-4 text-sm text-stone-300">
                  Al confirmar, su solicitud será enviada al equipo Ecogarzones para validación. Recibirá una respuesta en 24 horas hábiles.
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between mt-6 pt-5 border-t border-stone-800">
              <button
                onClick={() => setStep(s => Math.max(0, s - 1))}
                disabled={step === 0}
                className="px-5 py-2.5 text-sm font-medium text-stone-300 border border-stone-700 rounded-full hover:bg-stone-800 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              >
                Atrás
              </button>
              {step < 3 ? (
                <button
                  onClick={nextStep}
                  disabled={step === 0 && (!form.nombre || !form.fecha || !form.lugar)}
                  className="px-6 py-2.5 text-sm font-semibold text-stone-950 bg-gradient-to-r from-amber-200 via-amber-400 to-orange-500 rounded-full hover:from-amber-100 hover:to-orange-400 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Siguiente →
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  className="px-6 py-2.5 text-sm font-semibold text-stone-950 bg-gradient-to-r from-amber-200 via-amber-400 to-orange-500 rounded-full hover:from-amber-100 hover:to-orange-400 transition-colors"
                >
                  ✓ Enviar Solicitud
                </button>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-16 venue-panel">
          <div className="text-6xl mb-4">🎉</div>
          <h2 className="text-white text-2xl editorial-title mb-2">¡Solicitud Enviada!</h2>
          <p className="text-stone-400 text-sm mb-6">Tu evento <strong className="text-white">"{form.nombre}"</strong> está siendo procesado.</p>
          <button onClick={reset} className="px-6 py-2.5 text-sm font-semibold text-stone-950 bg-gradient-to-r from-amber-200 via-amber-400 to-orange-500 rounded-full">
            Solicitar otro evento
          </button>
        </div>
      )}
    </div>
  );
}
