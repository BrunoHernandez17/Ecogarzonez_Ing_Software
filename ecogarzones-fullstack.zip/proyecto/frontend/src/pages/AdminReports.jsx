import { useData } from "../context/DataContext";

export default function AdminReports() {
  const { events } = useData();
  const fmt = (n) => `$${n.toLocaleString("es-CL")}`;

  const validEvents = events.filter(e => e.estado !== "rechazado");
  const totalIngresos = validEvents.reduce((s, e) => s + (e.calculo?.costoTotal || 0), 0);
  const totalAlimentos = validEvents.reduce((s, e) => s + (e.calculo?.costoBase || 0), 0);
  const totalPersonal = validEvents.reduce((s, e) => s + (e.calculo?.costoPersonal || 0), 0);

  const byStatus = {
    pendiente: events.filter(e => e.estado === "pendiente").length,
    aprobado: events.filter(e => e.estado === "aprobado").length,
    completado: events.filter(e => e.estado === "completado").length,
    rechazado: events.filter(e => e.estado === "rechazado").length,
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Reportes de Costos
        </h1>
        <p className="text-stone-400 text-sm mt-1">Consolidado financiero del sistema</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Ingresos Totales", value: fmt(totalIngresos), icon: "💰", sub: `${validEvents.length} eventos`, color: "emerald" },
          { label: "Costo Alimentos", value: fmt(totalAlimentos), icon: "🍽️", sub: `${Math.round((totalAlimentos/totalIngresos || 0)*100)}% del total`, color: "blue" },
          { label: "Costo Personal", value: fmt(totalPersonal), icon: "👥", sub: `${Math.round((totalPersonal/totalIngresos || 0)*100)}% del total`, color: "purple" },
        ].map(c => (
          <div key={c.label} className={`bg-stone-900/60 border border-stone-800 rounded-2xl p-5`}>
            <div className="flex justify-between items-start mb-3">
              <p className="text-stone-400 text-sm">{c.label}</p>
              <span className="text-xl">{c.icon}</span>
            </div>
            <p className="text-white text-xl font-bold">{c.value}</p>
            <p className="text-stone-600 text-xs mt-1">{c.sub}</p>
          </div>
        ))}
      </div>

      {/* Status distribution */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-2xl p-6">
        <h2 className="text-white font-semibold mb-5">Distribución por Estado</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { key: "pendiente", label: "Pendientes", color: "text-yellow-400" },
            { key: "aprobado", label: "Aprobados", color: "text-emerald-400" },
            { key: "completado", label: "Completados", color: "text-blue-400" },
            { key: "rechazado", label: "Rechazados", color: "text-red-400" },
          ].map(s => (
            <div key={s.key} className="text-center bg-stone-800/40 rounded-xl p-4">
              <p className={`text-3xl font-bold ${s.color}`}>{byStatus[s.key]}</p>
              <p className="text-stone-500 text-xs mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Event detail table */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-stone-800">
          <h2 className="text-white font-semibold">Detalle por Evento</h2>
        </div>
        {events.length === 0 ? (
          <div className="p-12 text-center">
            <div className="text-4xl mb-3">📊</div>
            <p className="text-stone-400">No hay datos para mostrar</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-stone-800">
                  {["Evento", "Asistentes", "Costo Alimentos", "Costo Personal", "Total", "x Persona"].map(h => (
                    <th key={h} className="text-left text-stone-500 text-xs font-medium uppercase tracking-wider px-5 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/50">
                {events.map(e => (
                  <tr key={e.id} className="hover:bg-stone-800/20 transition-colors">
                    <td className="px-5 py-3.5 text-white font-medium">{e.nombre}</td>
                    <td className="px-5 py-3.5 text-stone-400">{e.asistentes}</td>
                    <td className="px-5 py-3.5 text-stone-300">{fmt(e.calculo?.costoBase || 0)}</td>
                    <td className="px-5 py-3.5 text-stone-300">{fmt(e.calculo?.costoPersonal || 0)}</td>
                    <td className="px-5 py-3.5 text-emerald-400 font-semibold">{fmt(e.calculo?.costoTotal || 0)}</td>
                    <td className="px-5 py-3.5 text-stone-400">{fmt(e.calculo?.porPersona || 0)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-stone-700 bg-stone-800/30">
                  <td className="px-5 py-3.5 text-white font-bold" colSpan={2}>TOTAL</td>
                  <td className="px-5 py-3.5 text-white font-bold">{fmt(totalAlimentos)}</td>
                  <td className="px-5 py-3.5 text-white font-bold">{fmt(totalPersonal)}</td>
                  <td className="px-5 py-3.5 text-emerald-400 font-bold text-base">{fmt(totalIngresos)}</td>
                  <td className="px-5 py-3.5" />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
