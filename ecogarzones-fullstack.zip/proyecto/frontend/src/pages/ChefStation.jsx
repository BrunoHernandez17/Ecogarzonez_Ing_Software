import { useState } from "react";
import { useData } from "../context/DataContext";

const CATEGORIES = ["entrada", "principal", "postre"];
const ALL_TAGS = ["vegano", "vegetariano", "sin-gluten", "sin-lactosa"];

const CAT_CONFIG = {
  entrada: { label: "Entradas", icon: "🥗", color: "blue" },
  principal: { label: "Platos Principales", icon: "🍽️", color: "emerald" },
  postre: { label: "Postres", icon: "🍰", color: "purple" },
};

function DishCard({ dish, onEdit, onDelete }) {
  return (
    <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 hover:border-stone-700 transition-all group">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="text-white font-medium text-sm leading-snug">{dish.name}</h3>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
          <button onClick={() => onEdit(dish)} className="w-7 h-7 flex items-center justify-center rounded-lg bg-stone-800 text-stone-400 hover:text-blue-400 text-xs transition-colors">✏️</button>
          <button onClick={() => onDelete(dish.id)} className="w-7 h-7 flex items-center justify-center rounded-lg bg-stone-800 text-stone-400 hover:text-red-400 text-xs transition-colors">🗑️</button>
        </div>
      </div>
      <div className="flex items-center gap-3 text-xs text-stone-500 mb-3">
        <span>💰 ${dish.costo.toLocaleString("es-CL")}</span>
        <span>🔥 {dish.calorias} kcal</span>
      </div>
      {dish.tags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {dish.tags.map(t => (
            <span key={t} className="px-2 py-0.5 bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 rounded-md text-xs">{t}</span>
          ))}
        </div>
      )}
    </div>
  );
}

const EMPTY_FORM = { name: "", category: "principal", costo: 3000, calorias: 400, tags: [] };

export default function ChefStation({ view }) {
  const { dishes, addDish, updateDish, deleteDish, events } = useData();
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);

  const openAdd = () => { setForm(EMPTY_FORM); setEditing(null); setShowForm(true); };
  const openEdit = (dish) => { setForm({ ...dish }); setEditing(dish.id); setShowForm(true); };

  const handleSave = () => {
    if (!form.name) return;
    if (editing) updateDish(editing, form);
    else addDish(form);
    setShowForm(false);
    setEditing(null);
    setForm(EMPTY_FORM);
  };

  const handleTag = (t) => setForm(p => ({
    ...p,
    tags: p.tags.includes(t) ? p.tags.filter(x => x !== t) : [...p.tags, t]
  }));

  const assignedEvents = events.filter(e => e.estado === "aprobado");

  if (view === "eventos-chef") {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Eventos Asignados
        </h1>
        {assignedEvents.length === 0 ? (
          <div className="text-center py-16 bg-stone-900/60 border border-stone-800 rounded-2xl">
            <div className="text-4xl mb-3">📭</div>
            <p className="text-stone-400">No hay eventos aprobados actualmente</p>
          </div>
        ) : (
          <div className="space-y-4">
            {assignedEvents.map(e => (
              <div key={e.id} className="bg-stone-900/60 border border-stone-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-white font-semibold">{e.nombre}</h3>
                  <span className="text-xs text-emerald-400 bg-emerald-950/50 border border-emerald-800/50 px-2.5 py-1 rounded-lg">Aprobado</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm text-stone-400 mb-4">
                  <span>📅 {new Date(e.fecha).toLocaleDateString("es-CL")}</span>
                  <span>👥 {e.asistentes} personas</span>
                </div>
                <div>
                  <p className="text-stone-500 text-xs mb-2 uppercase tracking-wider">Menú del evento</p>
                  <div className="grid gap-1.5">
                    {e.calculo?.menuSugerido?.map(d => (
                      <div key={d.id} className="flex items-center gap-2 text-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0" />
                        <span className="text-stone-300">{d.name}</span>
                        <span className="text-stone-600 text-xs ml-auto">×{e.asistentes} porciones</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
            Recetas y Menús
          </h1>
          <p className="text-stone-400 text-sm mt-1">{dishes.length} platos en el sistema</p>
        </div>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-orange-500 to-red-600 rounded-xl hover:from-orange-400 hover:to-red-500 transition-colors shadow-lg"
        >
          ＋ Nuevo Plato
        </button>
      </div>

      {/* Dishes by category */}
      {CATEGORIES.map(cat => {
        const catDishes = dishes.filter(d => d.category === cat);
        const conf = CAT_CONFIG[cat];
        return (
          <div key={cat} className="bg-stone-900/40 border border-stone-800 rounded-2xl overflow-hidden">
            <div className="flex items-center gap-3 p-5 border-b border-stone-800">
              <span className="text-xl">{conf.icon}</span>
              <h2 className="text-white font-semibold">{conf.label}</h2>
              <span className="ml-auto text-stone-600 text-sm">{catDishes.length} platos</span>
            </div>
            {catDishes.length === 0 ? (
              <div className="p-8 text-center text-stone-600 text-sm">Sin platos en esta categoría</div>
            ) : (
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {catDishes.map(d => (
                  <DishCard key={d.id} dish={d} onEdit={openEdit} onDelete={deleteDish} />
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-700 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-white font-bold text-lg mb-5">{editing ? "Editar Plato" : "Nuevo Plato"}</h2>
            <div className="space-y-4">
              <div>
                <label className="text-stone-400 text-sm font-medium block mb-2">Nombre del plato</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors"
                  placeholder="Ej: Risotto de hongos"
                />
              </div>
              <div>
                <label className="text-stone-400 text-sm font-medium block mb-2">Categoría</label>
                <select
                  value={form.category}
                  onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors"
                >
                  {CATEGORIES.map(c => <option key={c} value={c}>{CAT_CONFIG[c].label}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-2">Costo (CLP)</label>
                  <input
                    type="number"
                    value={form.costo}
                    onChange={e => setForm(p => ({ ...p, costo: +e.target.value }))}
                    className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-stone-400 text-sm font-medium block mb-2">Calorías</label>
                  <input
                    type="number"
                    value={form.calorias}
                    onChange={e => setForm(p => ({ ...p, calorias: +e.target.value }))}
                    className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="text-stone-400 text-sm font-medium block mb-2">Etiquetas dietéticas</label>
                <div className="flex flex-wrap gap-2">
                  {ALL_TAGS.map(t => (
                    <button key={t} onClick={() => handleTag(t)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                        form.tags.includes(t)
                          ? "bg-emerald-950/60 border-emerald-700 text-emerald-300"
                          : "bg-stone-800 border-stone-700 text-stone-400 hover:border-stone-600"
                      }`}
                    >{t}</button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowForm(false)} className="flex-1 py-2.5 text-sm text-stone-400 border border-stone-700 rounded-xl hover:bg-stone-800 transition-colors">
                Cancelar
              </button>
              <button onClick={handleSave} className="flex-1 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-orange-500 to-red-600 rounded-xl hover:from-orange-400 hover:to-red-500 transition-colors">
                {editing ? "Guardar cambios" : "Crear plato"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
