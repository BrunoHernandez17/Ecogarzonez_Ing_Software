import { useState } from "react";
import { useData } from "../context/DataContext";

const ROLE_LABELS = {
  garzon: { label: "Garzón", color: "text-blue-400 bg-blue-950/50 border-blue-800/50" },
  ayudante: { label: "Ayudante", color: "text-yellow-400 bg-yellow-950/50 border-yellow-800/50" },
  coordinador: { label: "Coordinador", color: "text-purple-400 bg-purple-950/50 border-purple-800/50" },
};

function StaffChip({ member, selected, onToggle }) {
  const roleConf = ROLE_LABELS[member.role];
  return (
    <div
      onClick={onToggle}
      className={`
        flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all select-none
        ${selected
          ? "bg-purple-950/60 border-purple-700 shadow-sm"
          : member.disponible
            ? "bg-stone-800/60 border-stone-700 hover:border-stone-600"
            : "bg-stone-900/40 border-stone-800 opacity-50 cursor-not-allowed"
        }
      `}
    >
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${selected ? "bg-purple-500 text-white" : "bg-stone-700 text-stone-300"}`}>
        {member.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-white text-sm font-medium truncate">{member.name}</p>
        <div className="flex items-center gap-2">
          <span className={`text-xs px-1.5 py-0.5 rounded-md border ${roleConf.color}`}>{roleConf.label}</span>
          <span className="text-stone-600 text-xs">⭐ {member.rating}</span>
        </div>
      </div>
      {selected && <span className="text-purple-400 text-sm flex-shrink-0">✓</span>}
      {!member.disponible && !selected && <span className="text-stone-600 text-xs flex-shrink-0">No disp.</span>}
    </div>
  );
}

export default function SupervisorPanel({ view }) {
  const { events, staff, assignments, assignStaff } = useData();
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [selectedStaff, setSelectedStaff] = useState([]);
  const [saved, setSaved] = useState(false);

  const pendingApproved = events.filter(e => e.estado === "aprobado");

  const openAssignment = (event) => {
    setSelectedEvent(event);
    setSelectedStaff(assignments[event.id] || []);
    setSaved(false);
  };

  const toggleStaff = (id) => {
    const member = staff.find(s => s.id === id);
    if (!member?.disponible && !selectedStaff.includes(id)) return;
    setSelectedStaff(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);
  };

  const handleSave = () => {
    assignStaff(selectedEvent.id, selectedStaff);
    setSaved(true);
  };

  if (view === "eventos-supervisor") {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Todos los Eventos
        </h1>
        <div className="grid gap-4">
          {events.length === 0 ? (
            <div className="text-center py-16 text-stone-500">No hay eventos registrados</div>
          ) : events.map(e => (
            <div key={e.id} className="bg-stone-900/60 border border-stone-800 rounded-2xl p-5">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-white font-semibold">{e.nombre}</h3>
                  <p className="text-stone-400 text-sm mt-1">{new Date(e.fecha).toLocaleDateString("es-CL")} · {e.asistentes} personas</p>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-lg border ${
                  e.estado === "aprobado" ? "text-emerald-400 bg-emerald-950/50 border-emerald-800/50" :
                  e.estado === "pendiente" ? "text-yellow-400 bg-yellow-950/50 border-yellow-800/50" :
                  "text-stone-500 bg-stone-800/50 border-stone-700"
                }`}>{e.estado}</span>
              </div>
              {assignments[e.id] && (
                <p className="text-stone-500 text-xs mt-3">👥 {assignments[e.id].length} personas asignadas</p>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (view === "personal") {
    return (
      <div className="space-y-6 max-w-3xl mx-auto">
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Personal
        </h1>
        <div className="grid gap-3">
          {staff.map(m => {
            const conf = ROLE_LABELS[m.role];
            return (
              <div key={m.id} className="bg-stone-900/60 border border-stone-800 rounded-2xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-violet-700 flex items-center justify-center text-white font-bold flex-shrink-0">
                  {m.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium">{m.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-xs px-2 py-0.5 rounded-md border ${conf.color}`}>{conf.label}</span>
                    <span className="text-stone-500 text-xs">⭐ {m.rating}</span>
                  </div>
                </div>
                <div className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg ${m.disponible ? "bg-emerald-950/50 text-emerald-400" : "bg-stone-800 text-stone-500"}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${m.disponible ? "bg-emerald-400" : "bg-stone-600"}`} />
                  {m.disponible ? "Disponible" : "Ocupado"}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Main assignment view
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          Asignación de Personal
        </h1>
        <p className="text-stone-400 text-sm mt-1">Asigna garzones y ayudantes a los eventos aprobados</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Event list */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-2xl overflow-hidden">
          <div className="p-5 border-b border-stone-800">
            <h2 className="text-white font-semibold">Eventos Aprobados</h2>
            <p className="text-stone-500 text-xs mt-0.5">{pendingApproved.length} eventos requieren personal</p>
          </div>
          {pendingApproved.length === 0 ? (
            <div className="p-12 text-center">
              <div className="text-4xl mb-3">📭</div>
              <p className="text-stone-400 text-sm">No hay eventos aprobados</p>
            </div>
          ) : (
            <div className="divide-y divide-stone-800">
              {pendingApproved.map(e => {
                const assigned = assignments[e.id] || [];
                const needed = e.calculo?.totalPersonal || 0;
                const isSelected = selectedEvent?.id === e.id;

                return (
                  <button
                    key={e.id}
                    onClick={() => openAssignment(e)}
                    className={`w-full text-left p-5 transition-colors ${isSelected ? "bg-purple-950/30" : "hover:bg-stone-800/30"}`}
                  >
                    <div className="flex justify-between items-start mb-1.5">
                      <h3 className="text-white font-medium text-sm">{e.nombre}</h3>
                      {isSelected && <span className="text-purple-400 text-xs">Editando</span>}
                    </div>
                    <p className="text-stone-500 text-xs mb-2">{new Date(e.fecha).toLocaleDateString("es-CL")} · {e.asistentes} personas</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-stone-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${assigned.length >= needed ? "bg-emerald-500" : "bg-purple-500"}`}
                          style={{ width: `${Math.min(100, (assigned.length / Math.max(needed, 1)) * 100)}%` }}
                        />
                      </div>
                      <span className={`text-xs font-medium ${assigned.length >= needed ? "text-emerald-400" : "text-purple-400"}`}>
                        {assigned.length}/{needed}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Staff assignment panel */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-2xl overflow-hidden">
          {!selectedEvent ? (
            <div className="p-12 text-center h-full flex flex-col items-center justify-center">
              <div className="text-4xl mb-3">👆</div>
              <p className="text-stone-400 text-sm">Selecciona un evento para asignar personal</p>
            </div>
          ) : (
            <>
              <div className="p-5 border-b border-stone-800">
                <h2 className="text-white font-semibold">{selectedEvent.nombre}</h2>
                <p className="text-stone-500 text-xs mt-0.5">
                  Necesita: {selectedEvent.calculo?.garzones} garzones · {selectedEvent.calculo?.ayudantes} ayudantes
                </p>
              </div>
              <div className="p-4 space-y-2 max-h-80 overflow-y-auto">
                {staff.map(m => (
                  <StaffChip
                    key={m.id}
                    member={m}
                    selected={selectedStaff.includes(m.id)}
                    onToggle={() => toggleStaff(m.id)}
                  />
                ))}
              </div>
              <div className="p-4 border-t border-stone-800 flex items-center justify-between gap-3">
                <span className="text-stone-500 text-sm">{selectedStaff.length} personas seleccionadas</span>
                {saved ? (
                  <span className="text-emerald-400 text-sm font-medium">✓ Guardado</span>
                ) : (
                  <button
                    onClick={handleSave}
                    className="px-5 py-2 text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-violet-600 rounded-xl hover:from-purple-500 hover:to-violet-500 transition-colors"
                  >
                    Guardar asignación
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
