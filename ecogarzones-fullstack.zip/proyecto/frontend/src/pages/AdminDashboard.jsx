import { useData } from "../context/DataContext";

const STATUS_CONFIG = {
  pendiente: { label: "Pendiente", color: "text-yellow-400 bg-yellow-950/50 border-yellow-800/50" },
  aprobado: { label: "Aprobado", color: "text-amber-300 bg-amber-950/40 border-amber-800/50" },
  rechazado: { label: "Rechazado", color: "text-red-400 bg-red-950/50 border-red-800/50" },
  completado: { label: "Completado", color: "text-blue-400 bg-blue-950/50 border-blue-800/50" },
};

function StatCard({ label, value, icon, sub, color = "amber" }) {
  const colors = {
    amber: "from-amber-950/80 to-orange-950/40 border-amber-800/30",
    blue: "from-stone-900/90 to-slate-950/40 border-slate-700/40",
    yellow: "from-yellow-900/40 to-amber-900/40 border-yellow-800/30",
    stone: "from-stone-900/90 to-stone-950/50 border-stone-700/40",
  };
  const iconColors = {
    amber: "bg-amber-500/20 text-amber-300",
    blue: "bg-slate-500/20 text-slate-300",
    yellow: "bg-yellow-500/20 text-yellow-300",
    stone: "bg-stone-500/20 text-stone-300",
  };

  return (
    <div className={`bg-gradient-to-br ${colors[color]} border rounded-[26px] p-5 backdrop-blur-xl shadow-xl shadow-black/10`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-stone-400 text-sm font-medium uppercase tracking-[0.2em]">{label}</p>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-base ${iconColors[color]}`}>{icon}</div>
      </div>
      <p className="text-white text-3xl mb-1 editorial-title">{value}</p>
      {sub && <p className="text-stone-500 text-xs">{sub}</p>}
    </div>
  );
}

export default function AdminDashboard() {
  const { events, updateEventStatus, getStats } = useData();
  const stats = getStats();

  const pendientes = events.filter(e => e.estado === "pendiente");
  const recientes = events.slice(0, 5);

  const fmt = (n) => `$${n.toLocaleString("es-CL")}`;
  const fmtDate = (s) => new Date(s).toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" });

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div>
        <p className="text-[11px] uppercase tracking-[0.35em] text-stone-500 mb-2">Resumen ejecutivo</p>
        <h1 className="text-white text-3xl sm:text-4xl editorial-title">
          Dashboard Administrativo
        </h1>
        <p className="text-stone-400 text-sm mt-2 max-w-2xl">Resumen operacional, aprobaciones pendientes y movimiento reciente del sistema.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Eventos" value={stats.total} icon="📋" sub="en el sistema" color="amber" />
        <StatCard label="Pendientes" value={stats.pendientes} icon="⏳" sub="requieren validación" color="yellow" />
        <StatCard label="Aprobados" value={stats.aprobados} icon="✅" sub="en curso" color="blue" />
        <StatCard label="Ingresos Est." value={fmt(stats.ingresoTotal)} icon="💰" sub="total proyectado" color="stone" />
      </div>

      {/* Pending approvals */}
      <div className="venue-panel overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-stone-800">
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-stone-500 mb-2">Aprobaciones</p>
            <h2 className="text-white font-semibold text-lg">Solicitudes Pendientes</h2>
            <p className="text-stone-500 text-xs mt-0.5">{pendientes.length} evento(s) esperando aprobación</p>
          </div>
          {pendientes.length > 0 && (
            <span className="bg-yellow-500/10 text-yellow-300 text-xs font-bold px-3 py-1.5 rounded-full border border-yellow-800/50 uppercase tracking-[0.2em]">
              {pendientes.length} nuevo(s)
            </span>
          )}
        </div>

        {pendientes.length === 0 ? (
          <div className="p-12 text-center">
            <div className="text-4xl mb-3">✅</div>
            <p className="text-stone-400">No hay solicitudes pendientes</p>
          </div>
        ) : (
          <div className="divide-y divide-stone-800">
            {pendientes.map(event => (
              <div key={event.id} className="p-6 hover:bg-stone-800/20 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-white font-medium text-sm truncate">{event.nombre}</h3>
                      <span className="text-xs text-stone-500">{fmtDate(event.fecha)}</span>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-1.5 text-xs text-stone-400">
                      <span>👥 {event.asistentes} asistentes</span>
                      <span>🍽️ {event.calculo?.menuSugerido?.length || 0} platos</span>
                      <span>👔 {event.calculo?.totalPersonal || 0} personal</span>
                      <span className="text-amber-300 font-medium">{fmt(event.calculo?.costoTotal || 0)}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button
                      onClick={() => updateEventStatus(event.id, "rechazado")}
                      className="px-3 py-1.5 text-xs font-medium text-red-400 border border-red-800/50 rounded-lg hover:bg-red-950/40 transition-colors"
                    >
                      Rechazar
                    </button>
                    <button
                      onClick={() => updateEventStatus(event.id, "aprobado")}
                      className="px-4 py-2 text-xs font-semibold text-stone-950 bg-gradient-to-r from-amber-200 via-amber-400 to-orange-500 rounded-full hover:from-amber-100 hover:to-orange-400 transition-colors shadow-sm"
                    >
                      Aprobar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent events table */}
      <div className="venue-panel overflow-hidden">
        <div className="p-6 border-b border-stone-800">
          <p className="text-[11px] uppercase tracking-[0.3em] text-stone-500 mb-2">Actividad</p>
          <h2 className="text-white font-semibold text-lg">Eventos Recientes</h2>
        </div>
        {recientes.length === 0 ? (
          <div className="p-12 text-center">
            <div className="text-4xl mb-3">📭</div>
            <p className="text-stone-400">No hay eventos registrados aún</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-stone-800">
                  {["Evento", "Fecha", "Asistentes", "Costo Total", "Estado"].map(h => (
                    <th key={h} className="text-left text-stone-500 text-[11px] font-medium uppercase tracking-[0.25em] px-6 py-4">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/50">
                {recientes.map(event => {
                  const sc = STATUS_CONFIG[event.estado] || STATUS_CONFIG.pendiente;
                  return (
                    <tr key={event.id} className="hover:bg-stone-800/20 transition-colors">
                      <td className="px-6 py-4 text-white font-medium">{event.nombre}</td>
                      <td className="px-6 py-4 text-stone-400">{fmtDate(event.fecha)}</td>
                      <td className="px-6 py-4 text-stone-300">{event.asistentes}</td>
                      <td className="px-6 py-4 text-amber-300 font-medium">{fmt(event.calculo?.costoTotal || 0)}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-medium border ${sc.color}`}>
                          {sc.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
