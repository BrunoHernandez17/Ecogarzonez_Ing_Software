import { useData } from "../context/DataContext";
import { useAuth } from "../context/AuthContext";

export default function EmployeeView({ view }) {
  const { events, assignments, staff } = useData();
  const { user } = useAuth();

  // Find this employee in staff (simulate by index)
  const myStaffId = 1; // Pedro Alvarado as demo employee
  const myEvents = events.filter(e => (assignments[e.id] || []).includes(myStaffId));
  const upcomingEvents = myEvents.filter(e => e.estado === "aprobado");

  const fmtDate = (s) => new Date(s).toLocaleDateString("es-CL", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          {view === "mis-turnos" ? "Mis Turnos" : "Mis Eventos"}
        </h1>
        <p className="text-stone-400 text-sm mt-1">
          {view === "mis-turnos" ? "Próximos turnos asignados" : "Historial de eventos"}
        </p>
      </div>

      {upcomingEvents.length === 0 ? (
        <div className="text-center py-20 bg-stone-900/60 border border-stone-800 rounded-2xl">
          <div className="text-5xl mb-4">📅</div>
          <p className="text-stone-400">No tienes eventos asignados próximamente</p>
          <p className="text-stone-600 text-sm mt-2">Tu supervisor te notificará cuando seas asignado</p>
        </div>
      ) : (
        <div className="space-y-4">
          {upcomingEvents.map(e => (
            <div key={e.id} className="bg-stone-900/60 border border-stone-800 rounded-2xl p-5">
              <div className="flex items-start gap-4">
                <div className="bg-emerald-950/60 border border-emerald-800/40 rounded-xl p-3 text-center flex-shrink-0 w-16">
                  <p className="text-emerald-400 text-lg font-bold leading-none">
                    {new Date(e.fecha).getDate()}
                  </p>
                  <p className="text-stone-500 text-xs mt-0.5">
                    {new Date(e.fecha).toLocaleDateString("es-CL", { month: "short" })}
                  </p>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-semibold">{e.nombre}</h3>
                  <p className="text-stone-400 text-sm mt-0.5 capitalize">{fmtDate(e.fecha)}</p>
                  <div className="flex flex-wrap gap-3 mt-2 text-xs text-stone-500">
                    <span>📍 {e.lugar}</span>
                    <span>👥 {e.asistentes} personas</span>
                  </div>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-stone-800">
                <p className="text-stone-500 text-xs uppercase tracking-wider mb-2">Tu rol en este evento</p>
                <div className="flex gap-2">
                  <span className="bg-blue-950/50 border border-blue-800/50 text-blue-400 text-xs px-3 py-1.5 rounded-lg font-medium">🤵 Garzón</span>
                  <span className="bg-stone-800/60 border border-stone-700 text-stone-400 text-xs px-3 py-1.5 rounded-lg">Servicio de mesa</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="bg-stone-900/40 border border-stone-800 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-3">Mi Resumen</h2>
        <div className="grid grid-cols-3 gap-3 text-center">
          {[
            { label: "Eventos totales", value: myEvents.length },
            { label: "Próximos", value: upcomingEvents.length },
            { label: "Mi rating", value: "4.8 ⭐" },
          ].map(s => (
            <div key={s.label} className="bg-stone-800/60 rounded-xl p-3">
              <p className="text-white font-bold text-xl">{s.value}</p>
              <p className="text-stone-500 text-xs mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
