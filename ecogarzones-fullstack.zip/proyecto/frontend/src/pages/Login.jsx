import { useState } from "react";
import { useAuth } from "../context/AuthContext";

const DEMO_USERS = [
  { label: "Administrador", username: "admin", password: "admin123", color: "from-amber-200 to-amber-500" },
  { label: "Cliente", username: "cliente", password: "cliente123", color: "from-stone-200 to-amber-500" },
  { label: "Chef", username: "chef", password: "chef123", color: "from-orange-200 to-orange-500" },
  { label: "Supervisor", username: "supervisor", password: "super123", color: "from-zinc-200 to-stone-500" },
  { label: "Empleado", username: "empleado", password: "emp123", color: "from-stone-300 to-stone-600" },
];

export default function Login() {
  const { login, error, setError } = useAuth();
  const [form, setForm] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await login(form.username, form.password);
    setLoading(false);
  };

  const fillDemo = (u) => {
    setError("");
    setForm({ username: u.username, password: u.password });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 right-0 w-[32rem] h-[32rem] bg-amber-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-28 -left-10 w-[28rem] h-[28rem] bg-orange-700/12 rounded-full blur-3xl" />
        <div className="absolute inset-0 opacity-[0.06]" style={{
          backgroundImage: "linear-gradient(rgba(208, 169, 101, 0.14) 1px, transparent 1px), linear-gradient(90deg, rgba(208, 169, 101, 0.14) 1px, transparent 1px)",
          backgroundSize: "72px 72px"
        }} />
      </div>

      <div className="w-full max-w-6xl relative z-10 venue-panel overflow-hidden">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
          <section className="relative px-6 py-8 sm:px-10 sm:py-12 border-b border-stone-800/70 lg:border-b-0 lg:border-r">
            <p className="text-[11px] uppercase tracking-[0.4em] text-stone-400 mb-4">Centro de eventos corporativos</p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white leading-none editorial-title max-w-xl">
              Ecogarzones con una presencia mas sobria y premium.
            </h1>
            <p className="text-stone-300/85 text-sm sm:text-base mt-5 max-w-lg leading-7">
              Mantiene la estructura operativa del sistema, pero ahora con una visual inspirada en venues editoriales: contrastes altos, acentos arena y superficies mas elegantes.
            </p>

            <div className="grid grid-cols-2 gap-3 mt-8 max-w-xl">
              {[
                ["Eventos", "300+"],
                ["Capacidad operativa", "24/7"],
                ["Clientes activos", "18"],
                ["Respuesta", "<24h"],
              ].map(([label, value]) => (
                <div key={label} className="venue-card p-4">
                  <p className="text-stone-500 text-[11px] uppercase tracking-[0.28em]">{label}</p>
                  <p className="text-white text-2xl mt-3 editorial-title">{value}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <span className="venue-button-primary">Produccion ejecutiva</span>
              <span className="venue-button-secondary">Operaciones coordinadas</span>
            </div>
          </section>

          <section className="px-6 py-8 sm:px-10 sm:py-12">
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-br from-amber-200 to-amber-500 rounded-2xl shadow-2xl shadow-amber-950/30">
                <span className="text-xl text-stone-950">E</span>
              </div>
              <p className="text-[11px] uppercase tracking-[0.35em] text-stone-500 mt-5 mb-2">Acceso plataforma</p>
              <h2 className="text-white text-3xl editorial-title">Iniciar sesion</h2>
              <p className="text-stone-400 text-sm mt-2">Ingresa al panel con tu cuenta o usa un acceso rapido de demostracion.</p>
            </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-stone-400 text-sm font-medium block mb-2">Usuario</label>
              <input
                type="text"
                value={form.username}
                onChange={e => setForm(p => ({ ...p, username: e.target.value }))}
                placeholder="nombre de usuario"
                className="w-full bg-stone-950/60 border border-stone-700 rounded-2xl px-4 py-3.5 text-white placeholder-stone-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-500/20 transition-all text-sm"
                required
              />
            </div>
            <div>
              <label className="text-stone-400 text-sm font-medium block mb-2">Contraseña</label>
              <input
                type="password"
                value={form.password}
                onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                placeholder="••••••••"
                className="w-full bg-stone-950/60 border border-stone-700 rounded-2xl px-4 py-3.5 text-white placeholder-stone-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-500/20 transition-all text-sm"
                required
              />
            </div>

            {error && (
              <div className="bg-red-950/40 border border-red-800/50 rounded-2xl px-4 py-3 text-red-300 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-amber-200 via-amber-400 to-orange-500 hover:from-amber-100 hover:to-orange-400 text-stone-950 font-semibold py-3.5 rounded-full transition-all duration-200 shadow-lg shadow-amber-950/30 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Verificando...
                </span>
              ) : "Ingresar al Sistema"}
            </button>
          </form>

          {/* Demo roles */}
          <div className="mt-7 pt-6 border-t border-stone-700/50">
            <p className="text-stone-500 text-xs font-medium uppercase tracking-[0.3em] mb-3">Acceso rapido por rol</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {DEMO_USERS.map(u => (
                <button
                  key={u.username}
                  onClick={() => fillDemo(u)}
                  className="rounded-2xl border border-stone-700 bg-stone-950/45 px-3 py-3 text-left transition-all hover:border-stone-500 hover:bg-stone-900/80"
                >
                  <span className={`block w-8 h-1.5 rounded-full bg-gradient-to-r ${u.color} mb-3`} />
                  <span className="block text-white text-xs font-medium truncate">{u.label}</span>
                </button>
              ))}
            </div>
          </div>

            <p className="text-center text-stone-600 text-xs mt-8">
              Sistema de demostracion · Datos simulados
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
